# prototype-plan addendum

This addendum keeps the original plan in `AGENTS.md` intact. It aligns the work with the assignment and the data actually received.

- The prototype consumes the supplied gate register and interview answers. No invoice export, e-way register, or Tally access has been supplied or authorised.
- The one LLM call extracts requirements from interviews. Code calculates every register count, date, time, duplicate, and gap. The model receives computed findings, not raw register rows.
- The first version does not integrate with Tally. It records invoice-backed daytime movements only when invoice details are supplied to the gate, and treats night chits as `invoice pending` records.
- E-way information can be recorded or flagged when supplied. The tool must not block a truck from the register alone because it has no consignment value.
- `run.sh` must remain the no-argument entry point and write schema-valid `output/result.json`. It calls the configured Gemini Flash model, then Gemini 3.8 Flash and Gemini 2.5 Flash if needed; it fails clearly if all calls fail.
- The output must label assumptions and report only evidenced conflicts. Deflections and unanswered questions belong in open questions, not conflicts.
- Before packaging, run `./run.sh`, validate the result against `data/output_schema.json`, and include the produced result, source data, write-up, and `.git` without virtual environments or `node_modules`.
